$pur_det=array();
                   $stock_det=array();
                   foreach($_POST['items'] as $item){